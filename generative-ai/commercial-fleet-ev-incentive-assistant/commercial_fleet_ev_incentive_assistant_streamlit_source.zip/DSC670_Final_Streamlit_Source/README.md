# DSC670 Final Project

Dan Morrow, Bellevue University

Commercial Fleet EV Incentive Assistant

## Submission contents

The Python source files are in `app/`. `DSC670_Final_Project_Morrow_D.pptx` is the eight-slide presentation with speaker notes and three actual running-application screenshots. Full screenshots are also in `screenshots/`. `evaluation/` retains the actual MPS/CPU live checks, individual review records and manual explanation assessment. `notebook/` contains the executed DTE full fine-tuning notebook with its original Colab outputs and the later live-result assessment. No video is included.

## Running the application

The model is Qwen2.5-0.5B-Instruct fully fine-tuned for the DTE workflow, run `1bcf2a3b1d8e`. All 494,032,768 parameters were trainable. Model weights are separate from this submission ZIP because the completed model bundle is about 2 GB. Use the already-created `DSC670_DTE_Complete_1bcf2a3b1d8e.zip` in Google Drive's `DSC670_DTE_Full_Fine_Tuning` folder, or reproduce a model bundle with the included Colab notebook. Keep the completed bundle's `app/`, `full_model/`, `reports/recipe.json`, `model_manifest.json` and `training_complete.json` together. The application verifies the model identity and saved files before loading.

From the completed bundle, install `app/requirements.txt` and run:

```bash
python -m streamlit run app/app.py --server.port 8502
```

Open http://localhost:8502 and select **Load saved model**. A source-only submission cannot perform inference without the saved weights and their sibling metadata. The included training notebook provides a reproducible GPU/Google Drive workflow without requiring a paid LLM API key. Re-training can produce different results.

## Recorded results

The authored notebook test records 64/64 correct decisions and structured checks. Its cases share authored scenario families with training and contain four project groups with 16 variants each. These results do not establish real-world accuracy. On six live app development cases, the model matched 5/6 decisions and passed 5/6 structured checks. Manual review found appropriate explanations in 4/6 cases. CPU reproduced the MPS responses exactly.

The complete standard example produced a $40,000 published ceiling from 16 ports at $2,500 per port. A missing meter/network arrangement prompted the correct question. Electric Choice exposed an incorrect rejection, which the independent Python decision check flagged. A different-utility case received the correct label with an incorrect explanation that the label comparison missed. All original responses remain in the evaluation files.

The app uses official DTE evidence reviewed November 8, 2026 and fictional customer facts. A published ceiling remains subject to DTE discretionary caps, documents, compliance and funding review. The application does not verify customer claims or perform a live funding search. Its observed errors limit it to a reviewed course prototype.

## Portfolio

https://danof2morrow.github.io/data-science-portfolio/

https://github.com/danof2morrow/data-science-portfolio/tree/main/generative-ai/commercial-fleet-ev-incentive-assistant
